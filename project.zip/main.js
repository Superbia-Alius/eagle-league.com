/**
 * EssCsLeague Node WEB server
 *
 * Author:    Superbia Alius
 * Created:   Nov 25, 2021
 * Copyright: (C) EssCsLeague
 */


const ejs      = require('ejs')                                // embedded preprocessable javascript
const express  = require('express')                            // web server
const router   = require('./router/router.js')                 // project web routes hub
const log      = require('./logs/logger.js').getLogger("main") // global logger

const tracingIncludes = "ejs, router, express, logger"         // < Please, add new includes to tracing
log.trace("Additional vendor modules included: " + tracingIncludes)



// App configuration
const port             = 3000
const viewEngine       = 'ejs'
const app              = express()
const staticPages      = 'pages/static'
const urlParser        = express.urlencoded({extended: false}) // to process POST requests


log.info("Application is configured")
log.trace(
  "Port: " + port + "\n" +
  "URL parser: urlencoded({extended: false})\n" +
  "View engine: " + viewEngine + "\n" +
  "WEB app engine: express\n" +
  "Static pages path: " + staticPages + "\n"
)


// App setting
try {
  app.set('view engine', viewEngine)
  router.setRoutes(app, urlParser)
}
catch(e) {
  log.fatal("Application stopped by configuration setting error: " + e)
  process.exit()
}
finally  { log.info("Application setted up successfully") }



// Stratup
app.listen(port, function() {
  log.info("The application WEB server is started . . .")
  console.log("Server started successfully . . .")
})
