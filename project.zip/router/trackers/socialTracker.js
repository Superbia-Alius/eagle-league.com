const database = require("./../../database/databaseManager.js")
// don't needs to be logged, because it's actually interface


var medias = new Map()
database.getRowByParam(database.config, 'CONFIG', 'NAME="VK"', function(err, row) {
  medias.set("vk", row.CONTENT)
})
database.getRowByParam(database.config, 'CONFIG', 'NAME="TW1"', function(err, row) {
  medias.set("tw1", row.CONTENT)
})
database.getRowByParam(database.config, 'CONFIG', 'NAME="TW2"', function(err, row) {
  medias.set("tw2", row.CONTENT)
})



function track(db, table, media) {
  database.createRow(db, table,
    "MEDIA, TIME",
    ["'"+media+"'", "'"+new Date()+"'"]
  )
}


exports.redirect = function(media, res) {
  track(database.redirects, "REDIRECTS", media)
  res.redirect(medias.get(media))
}
