const express        = require('express')
const posts          = require("./postsHandlers/indexHandler.js")
const configurer     = require("./pagesConfigurers/indexConfigurer.js")
const socialTracker  = require("./trackers/socialTracker.js")
const log            = require("./../logs/logger.js").getLogger("router")


const VIEWS    = __dirname + "./../pages/"
const STATIC   = VIEWS + "static/"
const EMBED    = VIEWS + "embeddable/"
log.info("Views directory is " + VIEWS + " and " + STATIC + " is completely public" + " and " + EMBED + " is embeddable")

configurer.getLandingCfg() // < Plug for loading



exports.setRoutes = function(app, urlEncodedParser) {
  // ------------- PUBLIC -------------
  app.use('/', express.static(STATIC))


  // ------------ TRIGGERS ------------
  // Landing page
  app.get('/', function(req, res) {
    log.trace("GET /")
    res.render(EMBED + '/index/index.ejs', {params: configurer.getLandingCfg()})
  })


  // Getting messages from landing contact form
  app.post("/", urlEncodedParser, function(req, res) {
    log.trace("POST / contact")
    posts.contact(req, res)
  })


  // Redirects to social media tracking
  app.get('/social/:media', function(req, res) {
    log.trace("GET /social/:media")
    socialTracker.redirect(req.params.media, res)
  })

}
