const database = require("./../../database/databaseManager.js")
// don't needs to be logged, because it's actually interface


var params = new Map()

exports.getLandingCfg = function() {
  database.getRowByParam(database.config, 'CONFIG', 'NAME="DESCRIPTION"', function(err, row) {
    params.set("description", row.CONTENT)
  })


  database.getRowByParam(database.config, 'CONFIG', 'NAME="BOARD"', function(err, row) {
    params.set("board", row.CONTENT)
  })


  database.getRowByParam(database.config, 'CONFIG', 'NAME="TEAM1"', function(err, row) {
    params.set("team1", row.CONTENT)
  })
  database.getRowByParam(database.config, 'CONFIG', 'NAME="TEAM2"', function(err, row) {
    params.set("team2", row.CONTENT)
  })
  database.getRowByParam(database.config, 'CONFIG', 'NAME="TEAM3"', function(err, row) {
    params.set("team3", row.CONTENT)
  })
  database.getRowByParam(database.config, 'CONFIG', 'NAME="TEAM4"', function(err, row) {
    params.set("team4", row.CONTENT)
  })
  database.getRowByParam(database.config, 'CONFIG', 'NAME="TEAM5"', function(err, row) {
    params.set("team5", row.CONTENT)
  })
  database.getRowByParam(database.config, 'CONFIG', 'NAME="TEAM6"', function(err, row) {
    params.set("team6", row.CONTENT)
  })
  database.getRowByParam(database.config, 'CONFIG', 'NAME="TEAM7"', function(err, row) {
    params.set("team7", row.CONTENT)
  })
  database.getRowByParam(database.config, 'CONFIG', 'NAME="TEAM8"', function(err, row) {
    params.set("team8", row.CONTENT)
  })


  database.getRowByParam(database.config, 'CONFIG', 'NAME="TEAM1_LOGO"', function(err, row) {
    params.set("team1_logo", row.CONTENT)
  })
  database.getRowByParam(database.config, 'CONFIG', 'NAME="TEAM2_LOGO"', function(err, row) {
    params.set("team2_logo", row.CONTENT)
  })
  database.getRowByParam(database.config, 'CONFIG', 'NAME="TEAM3_LOGO"', function(err, row) {
    params.set("team3_logo", row.CONTENT)
  })
  database.getRowByParam(database.config, 'CONFIG', 'NAME="TEAM4_LOGO"', function(err, row) {
    params.set("team4_logo", row.CONTENT)
  })
  database.getRowByParam(database.config, 'CONFIG', 'NAME="TEAM5_LOGO"', function(err, row) {
    params.set("team5_logo", row.CONTENT)
  })
  database.getRowByParam(database.config, 'CONFIG', 'NAME="TEAM6_LOGO"', function(err, row) {
    params.set("team6_logo", row.CONTENT)
  })
  database.getRowByParam(database.config, 'CONFIG', 'NAME="TEAM7_LOGO"', function(err, row) {
    params.set("team7_logo", row.CONTENT)
  })
  database.getRowByParam(database.config, 'CONFIG', 'NAME="TEAM8_LOGO"', function(err, row) {
    params.set("team8_logo", row.CONTENT)
  })


  database.getRowByParam(database.config, 'CONFIG', 'NAME="POSTER"', function(err, row) {
    params.set("poster", row.CONTENT)
  })


  return params
}
