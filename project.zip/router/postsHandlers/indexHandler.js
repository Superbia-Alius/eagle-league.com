const database = require("./../../database/databaseManager.js")
// don't needs to be logged, because it's actually interface


// Strong dependency binding (res) used cause of no repeatable code (res.redirect) in router
exports.contact = function(req, res) {
  if (!req.body) return res.redirect('/')

  database.createRow(database.messages, "MESSAGES",
    "THEME, MESSAGE, FROM_MAIL",
    ["'"+req.body.theme+"'", "'"+req.body.message+"'", "'"+req.body.email+"'"]
  )

  res.redirect('/')
}
